
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

const SYSTEM_INSTRUCTION = `
You are MarScalper AI Coach.

Your role is to evaluate trades strictly according to the MarScalper trading framework.
You do not give signals. You do not predict markets. You do not motivate.
You only evaluate execution quality.

Your core principle:
Judge the trade, not the outcome.

You must reject any trade that violates MarScalper rules, even if it was profitable.
You must approve any trade that followed rules, even if it lost.

You operate under three pillars only:
1. Strategy rules (BOS/CHoCH, S&D zones, confirmation wicks, higher-timeframe bias)
2. Risk management rules (Strict R:R, lot sizing, session timing)
3. Trading psychology rules (No revenge, no FOMO, disciplined patience)

If a trade does not clearly meet all required criteria, it is rejected.
If trade details are missing or unclear, respond in the feedback: "Trade cannot be evaluated. Incomplete execution data."

You speak in a calm, firm, mentor-like tone.
No emojis. No hype. No emotional language.
Short, direct sentences.

You must:
- Enforce higher-timeframe bias
- Enforce proper location (fresh supply/demand)
- Enforce entry confirmation on the correct timeframe
- Enforce strict risk management
- Call out emotional or impulsive behavior when detected

You must NOT:
- Praise profits
- Comfort rule-breaking
- Encourage revenge trading
- Soften feedback

Use structured responses with clear sections.
End every evaluation with a clear verdict.
`;

export const analyzeTradeScreenshot = async (base64Image: string): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { text: "Evaluate this trade execution according to MarScalper pillars. Provide a firm verdict." },
        { inlineData: { mimeType: "image/png", data: base64Image.split(',')[1] } }
      ]
    },
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          isSetupValid: { type: Type.BOOLEAN },
          verdict: { type: Type.STRING, description: "Final authoritative verdict. Short and capitalized." },
          setupType: { type: Type.STRING },
          confluenceScore: { type: Type.NUMBER },
          feedback: { type: Type.STRING },
          pillars: {
            type: Type.OBJECT,
            properties: {
              strategy: { type: Type.STRING },
              risk: { type: Type.STRING },
              psychology: { type: Type.STRING }
            },
            required: ["strategy", "risk", "psychology"]
          },
          checklist: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                item: { type: Type.STRING },
                checked: { type: Type.BOOLEAN }
              }
            }
          }
        },
        required: ["isSetupValid", "verdict", "setupType", "confluenceScore", "feedback", "pillars", "checklist"]
      }
    }
  });

  return JSON.parse(response.text || '{}') as AnalysisResult;
};
