
import React from 'react';

interface Props {
  children: React.ReactNode;
}

export const MarScalperLayout: React.FC<Props> = ({ children }) => {
  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col">
      {/* Background Layer */}
      <div className="absolute inset-0 z-0 bg-black">
        <div className="absolute inset-0 chart-bg"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-red-950 opacity-60"></div>
        {/* Martian Atmosphere Glow */}
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-red-800 rounded-full blur-[150px] opacity-20 animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-5%] w-[40%] h-[40%] bg-orange-900 rounded-full blur-[120px] opacity-10"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-red-900/50 bg-black/40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full mars-gradient flex items-center justify-center mars-glow">
              <span className="text-white font-orbitron font-bold text-xl">M</span>
            </div>
            <div>
              <h1 className="text-2xl font-orbitron font-bold tracking-tighter text-red-500 uppercase">
                MarScalper <span className="text-white">AI</span>
              </h1>
              <p className="text-[10px] uppercase tracking-widest text-red-400 font-semibold">Trading Coach • Mars Edition</p>
            </div>
          </div>
          <div className="hidden md:flex space-x-6 text-xs font-semibold uppercase tracking-widest text-gray-400">
            <span className="text-red-500">Live Status: Connected</span>
            <span>Deriv Protocol: Active</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex-grow p-4 md:p-8">
        <div className="max-w-7xl mx-auto h-full">
          {children}
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-red-900/30 bg-black/60 p-4 text-center">
        <p className="text-[10px] text-gray-500 uppercase tracking-widest">
          MarScalper Protocool v1.0.0-PROTOTYPE • Built for the Deriv Competition
        </p>
      </footer>
    </div>
  );
};
