
import React from 'react';

export const PlaybookRef: React.FC = () => {
  return (
    <div className="bg-black/60 border border-red-900/30 p-5 rounded-xl h-full overflow-y-auto custom-scrollbar backdrop-blur-sm">
      <h3 className="text-sm font-orbitron font-bold text-white mb-6 flex items-center border-b border-red-900/30 pb-4">
        <span className="w-2 h-2 bg-red-600 rounded-full mr-3"></span>
        PROTOCOL PARAMETERS
      </h3>

      <div className="space-y-8">
        <section>
          <h4 className="text-[10px] font-bold text-red-600 uppercase tracking-widest mb-3">Pillar I: Strategy</h4>
          <div className="space-y-4">
            <div>
              <p className="text-[11px] text-white font-bold mb-1">Momentum Break (A+)</p>
              <ul className="text-[10px] text-gray-500 space-y-1 list-disc list-inside">
                <li>BOS / CHoCH required</li>
                <li>Retest of fresh S&D zone</li>
                <li>Confirmation wick entry</li>
              </ul>
            </div>
            <div>
              <p className="text-[11px] text-white font-bold mb-1">Fakeout (A+)</p>
              <ul className="text-[10px] text-gray-500 space-y-1 list-disc list-inside">
                <li>Liquidity sweep of key level</li>
                <li>Immediate momentum shift</li>
                <li>Clean reversal candle</li>
              </ul>
            </div>
          </div>
        </section>

        <section>
          <h4 className="text-[10px] font-bold text-orange-600 uppercase tracking-widest mb-3">Pillar II: Risk</h4>
          <div className="text-[10px] text-gray-500 space-y-2">
            <p><span className="text-gray-300">Reward/Risk:</span> Minimum 3:1 required.</p>
            <p><span className="text-gray-300">Exposure:</span> Maximum 1% per setup.</p>
            <p><span className="text-gray-300">Session:</span> NASDAQ 16:30 - 17:30 UTC.</p>
          </div>
        </section>

        <section>
          <h4 className="text-[10px] font-bold text-blue-600 uppercase tracking-widest mb-3">Pillar III: Psychology</h4>
          <div className="text-[10px] text-gray-500 italic space-y-2 leading-relaxed">
            <p>"Execution is the only variable you control. The outcome belongs to the market."</p>
            <p>"Missing a trade is a victory of discipline. Forcing a trade is a defeat of character."</p>
          </div>
        </section>

        <div className="mt-6 pt-6 border-t border-red-900/20 text-center">
          <p className="text-[9px] text-red-900 font-bold uppercase tracking-tighter">
            Strict Adherence Required
          </p>
        </div>
      </div>
    </div>
  );
};
