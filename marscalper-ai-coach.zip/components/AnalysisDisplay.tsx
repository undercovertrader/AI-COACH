
import React from 'react';
import { AnalysisResult } from '../types';

interface Props {
  analysis: AnalysisResult;
}

export const AnalysisDisplay: React.FC<Props> = ({ analysis }) => {
  const scoreColor = analysis.confluenceScore > 7 ? 'text-green-500' : analysis.confluenceScore > 4 ? 'text-yellow-500' : 'text-red-500';

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Top Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-zinc-900/80 border border-red-900/30 p-4 rounded-lg">
          <p className="text-[10px] text-gray-500 uppercase tracking-[0.2em] mb-1">Execution Score</p>
          <p className={`text-2xl font-orbitron font-bold ${scoreColor}`}>
            {analysis.confluenceScore}/10
          </p>
        </div>
        <div className="bg-zinc-900/80 border border-red-900/30 p-4 rounded-lg">
          <p className="text-[10px] text-gray-500 uppercase tracking-[0.2em] mb-1">Pattern Identified</p>
          <p className="text-xl font-orbitron font-bold text-white uppercase truncate">{analysis.setupType}</p>
        </div>
        <div className="bg-zinc-900/80 border border-red-900/30 p-4 rounded-lg">
          <p className="text-[10px] text-gray-500 uppercase tracking-[0.2em] mb-1">Rule Adherence</p>
          <p className={`text-xl font-orbitron font-bold ${analysis.isSetupValid ? 'text-green-500' : 'text-red-500'}`}>
            {Math.round((analysis.checklist.filter(c => c.checked).length / analysis.checklist.length) * 100)}%
          </p>
        </div>
      </div>

      {/* Main Review */}
      <div className="bg-zinc-900/40 border border-red-900/20 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-red-900/20 bg-black/40">
          <h3 className="text-sm font-orbitron font-bold text-red-500 uppercase tracking-widest mb-4">Coach Evaluation</h3>
          <p className="text-gray-300 text-sm leading-relaxed font-medium italic">
            "{analysis.feedback}"
          </p>
        </div>

        <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Strategy Pillar */}
          <div className="space-y-4">
            <h4 className="text-[11px] font-bold text-gray-400 uppercase tracking-widest border-l-2 border-red-600 pl-3">Pillar I: Strategy</h4>
            <p className="text-xs text-gray-400 leading-relaxed">{analysis.pillars.strategy}</p>
          </div>

          {/* Risk Pillar */}
          <div className="space-y-4">
            <h4 className="text-[11px] font-bold text-gray-400 uppercase tracking-widest border-l-2 border-orange-600 pl-3">Pillar II: Risk</h4>
            <p className="text-xs text-gray-400 leading-relaxed">{analysis.pillars.risk}</p>
          </div>

          {/* Psychology Pillar */}
          <div className="space-y-4">
            <h4 className="text-[11px] font-bold text-gray-400 uppercase tracking-widest border-l-2 border-blue-600 pl-3">Pillar III: Psychology</h4>
            <p className="text-xs text-gray-400 leading-relaxed">{analysis.pillars.psychology}</p>
          </div>
        </div>

        {/* Checklist Section */}
        <div className="bg-black/20 p-6 border-t border-red-900/10">
          <h4 className="text-[11px] font-bold text-gray-500 uppercase tracking-widest mb-4">Tactical Checklist</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-y-3 gap-x-8">
            {analysis.checklist.map((item, idx) => (
              <div key={idx} className="flex items-start space-x-3">
                <div className={`mt-1 w-3 h-3 rounded-sm border flex-shrink-0 flex items-center justify-center ${item.checked ? 'bg-green-600/30 border-green-500' : 'bg-red-950/30 border-red-900'}`}>
                  {item.checked && <span className="text-[8px] text-green-400">✓</span>}
                </div>
                <span className={`text-[11px] ${item.checked ? 'text-gray-300' : 'text-gray-600'}`}>
                  {item.item}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Final Verdict - The most important part */}
        <div className={`p-6 text-center ${analysis.isSetupValid ? 'bg-green-950/20' : 'bg-red-950/20'} border-t border-red-900/20`}>
          <p className="text-[10px] text-gray-500 uppercase tracking-[0.3em] mb-2 font-bold">Formal Verdict</p>
          <h2 className={`text-4xl font-orbitron font-bold tracking-tighter ${analysis.isSetupValid ? 'text-green-500' : 'text-red-500'}`}>
            {analysis.verdict}
          </h2>
        </div>
      </div>
    </div>
  );
};
